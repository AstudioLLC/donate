<table class="table align-items-center table-flush dataTable">
    <thead class="thead-light">
    <tr>
        <th>{{ __('app.Donation.ID') }}</th>
        {{--<th>{{ __('app.Donation.Order ID') }}</th>--}}
        {{--<th>{{ __('app.Donation.MDORDER') }}</th>--}}
        <th>{{ __('app.Donation.Fundraiser') }}</th>
        <th>{{ __('app.Donation.Gift') }}</th>
        <th>{{ __('app.Donation.Binded') }}</th>
        <th>{{ __('app.Donation.Sponsor') }}</th>
        <th>{{ __('app.Donation.Child') }}</th>
        <th>{{ __('app.Donation.Amount') }}</th>
        <th>{{ __('app.List.Email') }}</th>
        <th>{{ __('app.List.Name') }}</th>
        {{--<th>{{ __('app.Donation.Message') }}</th>
        <th>{{ __('app.Donation.Admin message') }}</th>--}}
        <th>{{ __('app.List.Status') }}</th>
        <th>{{ __('app.List.Date') }}</th>
        <th>{{ __('app.Action') }}</th>
    </tr>
    </thead>
    <tbody class="list table-sortable" data-action="{{ route('admin.donations.sort') }}">

    </tbody>
</table>
